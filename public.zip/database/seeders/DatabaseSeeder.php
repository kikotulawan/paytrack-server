<?php

namespace Database\Seeders;

use App\Models\{User, UserInfo, Payment};
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Create superadmin user
        $superadmin = User::factory()->create([
            'email' => 'admin@paytrack.com',
        ]);

        UserInfo::create([
            'user_id' => $superadmin->id,
            'abbreviation' => 'PMSg',
            'firstname' => 'Paytrack',
            'middlename' => '',
            'lastname' => 'Administrator',
            'suffix' => '',
        ]);
        
        // Create staff user
        $staff = User::factory()->create([
            'email' => 'staff@paytrack.com',
        ]);

        UserInfo::create([
            'user_id' => $staff->id,
            'abbreviation' => 'PSSg',
            'firstname' => 'Paytrack',
            'middlename' => '',
            'lastname' => 'Staff',
            'suffix' => 'II',
        ]);
        
        // Create staff user
        $cashier = User::factory()->create([
            'email' => 'ezi@paytrack.com',
        ]);

        UserInfo::create([
            'user_id' => $cashier->id,
            'abbreviation' => '',
            'firstname' => 'Ezi',
            'middlename' => '',
            'lastname' => 'Pura',
            'suffix' => '',
        ]);
        
        $this->call(RolePermissionSeeder::class);

        // Add sample payment for User 3 (cashier)
        Payment::create([
            'user_id' => $cashier->id,
            'amount' => 1500.00,
            'or' => 72756096,
            'payor_name' => 'Juan Dela Cruz',
            'payment_date' => now()->toDateString(),
            'mode_of_payment' => 'Cash',
            'reference' => 'OR72756096',
            'nature_of_collection' => 'Neuro Examination Fee',
            'type' => 'trust-receipt-funds',
        ]);

        Payment::create([
            'user_id' => $cashier->id,
            'amount' => 1500.00,
            'or' => 72756097,
            'payor_name' => 'Mary Grace Oasis',
            'payment_date' => now()->toDateString(),
            'mode_of_payment' => 'E-wallet',
            'reference' => 'PAY-20250827-001',
            'nature_of_collection' => 'Drug Test',
            'type' => 'trust-receipt-funds',
        ]);
    }
}