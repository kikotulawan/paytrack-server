<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\{Permission, Role};
use App\Models\User;

class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        Permission::create(['name' => 'view activity logs', 'details' => 'Can view activity logs']);
        Permission::create(['name' => 'manage accounts', 'details' => 'Can create, update, delete user accounts']);
        Permission::create(['name' => 'manage trfs', 'details' => 'Can create, update, delete Trust Receipt Funds']);
        Permission::create(['name' => 'manage tls', 'details' => 'Can create, update, delete Trust Liabilities']);
        Permission::create(['name' => 'manage gfs', 'details' => 'Can create, update, delete General Funds']);
        Permission::create(['name' => 'manage reports', 'details' => 'Can generate reports']);

        $superadmin_role = Role::create(['name' => 'superadmin']);
        $staff_role = Role::create(['name' => 'staff']);
        $cashier_role = Role::create(['name' => 'cashier']);

        $superadmin_role->givePermissionTo(Permission::all());
        $staff_role->givePermissionTo(['manage trfs', 'manage tls', 'manage gfs', 'manage reports']);
        $cashier_role->givePermissionTo(['manage trfs', 'manage tls', 'manage gfs']);

        // Superadmin account must always be the first user (ID = 1)
        $superadmin = User::find(1);
        $superadmin->assignRole('superadmin');

        // Sample staff account
        $staff = User::find(2);
        $staff->assignRole('staff');

        $cashier = User::find(3);
        $cashier->assignRole('cashier');
    }
}