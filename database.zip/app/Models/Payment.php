<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $fillable = [
        'user_id',
        'amount',
        'or',
        'payor_name',
        'payment_date',
        'mode_of_payment',
        'reference',
        'nature_of_collection',
        'type',
    ];

    public $timestamps = true;
    
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}